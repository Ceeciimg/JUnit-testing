package com.dam.junit.ejercicio3;


import java.util.ArrayList;
import java.util.List;

public class CuentaBancariaAmpliada {


    //atributos
    private double saldo;
    private double saldoMinimo = 0; // No permite saldo negativo
    private List<String> historialTransacciones = new ArrayList<>();

    //constructor
    public CuentaBancariaAmpliada(double saldoInicial) {
        this.saldo = saldoInicial;
    }
    //Este método devuelve el saldo actual de la cuenta. 
    public double getSaldo() {
        return saldo;
    }
    // método para depositar dinero > 0.
    public void depositar(double cantidad) {
        if (cantidad > 0) {
            saldo += cantidad;
            historialTransacciones.add("Depósito: +" + cantidad);
        }
    }
       // retirar dinero
    public boolean retirar(double cantidad) {
        if (cantidad > 0 && saldo - cantidad >= saldoMinimo) {
            saldo -= cantidad;
            historialTransacciones.add("Retiro: -" + cantidad);
            return true;
        }
        return false;
    }

    // transferir dinero a otra cuenta bancaria 

    public boolean transferir(CuentaBancariaAmpliada destino, double cantidad) {
        if (retirar(cantidad)) {
            destino.depositar(cantidad);
            historialTransacciones.add("Transferencia: -" + cantidad + " a " + destino);
            return true;
        }
        return false;
    }

    //Este método devuelve la lista de todas las transacciones realizadas en la cuenta (depósitos, retiros, transferencias). 

    public List<String> getHistorialTransacciones() {
        return historialTransacciones;
    }

    //aplica un porcentaje de interés al saldo de la cuenta. 

    public void aplicarInteres(double porcentaje) {
        if (porcentaje > 0) {
            double interes = saldo * (porcentaje / 100);
            depositar(interes);
        }
    }
}
