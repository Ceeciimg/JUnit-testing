package com.dam.junit.ejercicio2;

//Este código define la clase CuentaBancaria, que representa una cuenta de banco con saldo
 //y operaciones básicas como depositar y retirar dinero.

public class CuentaBancaria {

    private double saldo; // saldo es un atributo privado, solo se accede dentro de la clase

    public CuentaBancaria(double saldoInicial) {   //construdctor 
        this.saldo = saldoInicial;
    }

    public double getSaldo() { // devuelve el saldo actual de la cuenta
        return saldo;
    }

    public void depositar(double cantidad) { // permite deporistar saldo con cantidad > 0
        if (cantidad > 0) {
            saldo += cantidad;
        }
    }

    public boolean retirar(double cantidad) {  // permite retirar dinero si hay una cantidad > 0 en la cuenta
        if (cantidad > 0 && saldo >= cantidad) {
            saldo -= cantidad;
            return true;
        }
        return false;
    }
}
