package com.dam.junit.ejercicio8;

import java.util.ArrayList;

public class Hotel {
    // atributos
    private ArrayList<Habitacion> habitaciones;
    private ArrayList<Reserva> reservas;
     // constructor 
    public Hotel(int totalHabitaciones) {
        this.habitaciones = new ArrayList<>();
        this.reservas = new ArrayList<>();
        
        // Crear las habitaciones del hotel
        for (int i = 1; i <= totalHabitaciones; i++) {
            habitaciones.add(new Habitacion(i));
        }
    }

    public boolean realizarReserva(String nombreCliente, int numeroHabitacion) {
        // Buscar la habitación
        for (Habitacion h : habitaciones) {
            if (h.getNumero() == numeroHabitacion && !h.estaReservada()) { // busca la habitación con el número indicado
                h.reservar();
                reservas.add(new Reserva(nombreCliente, numeroHabitacion)); //Crea una nueva reserva con el nombre del cliente y el número de habitación
                return true; // la reserva se ha realizado correctamente
            }
        }
        return false; // Habitación no disponible o no existe
    }

    public boolean cancelarReserva(int numeroHabitacion) {
        // Buscar la reserva y la elimina 
        for (int i = 0; i < reservas.size(); i++) {
            if (reservas.get(i).getNumeroHabitacion() == numeroHabitacion) {
                reservas.remove(i);
                // Marcar la habitación como disponible
                for (Habitacion h : habitaciones) {
                    if (h.getNumero() == numeroHabitacion) {
                        h.cancelarReserva();
                        return true;
                    }
                }
            }
        }
        return false; // No se ha encontrado la reserva
    }

    public ArrayList<Reserva> obtenerReservasActivas() { // devuelve una lista de las reservas activas
        return new ArrayList<>(reservas);
    }
}
