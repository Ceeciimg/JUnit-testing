
package com.dam.junit.ejercicio6;

import java.util.ArrayList;

public class Estudiante {

    // atributos 
    private String nombre;
    private ArrayList<Double> notas;

    // constructores 

    public Estudiante(String nombre, ArrayList<Double> notas) {
        this.nombre = nombre;
        this.notas = notas;
    }

    // devuelve el nombre del estudiante

    public String getNombre() {
        return nombre;
    }

    // devuelve la lsta de notas del estudiante

    public ArrayList<Double> getNotas() {
        return notas;
    }

    // promedio de notas del estudiante

    public double calcularPromedio() {
        if (notas.isEmpty()) return 0.0;
        double suma = 0;
        for (double nota : notas) {
            suma += nota;
        }
        return suma / notas.size();
    }

    // verifiar si el estudiante esta aprobado

    public boolean estaAprobado(double notaMinima) {
        return calcularPromedio() >= notaMinima;
    }
}
