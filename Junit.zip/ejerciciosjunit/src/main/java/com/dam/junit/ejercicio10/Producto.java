package com.dam.junit.ejercicio10;


public class Producto {

    // atributos 
    private String nombre;
    private String categoria;
    private double precio;
    private int stock;

    // Constructor con todos los atributos
    public Producto(String nombre, String categoria, double precio, int stock) {
        this.nombre = nombre;
        this.categoria = categoria;
        this.precio = precio;
        this.stock = stock;
    }

    // Constructor con valores predeterminados
    public Producto() {
        this.nombre = "Producto Desconocido";
        this.categoria = "Desconocida";
        this.precio = 0.0;
        this.stock = 0;
    }

    // Método para mostrar la información del producto
    public void mostrarInformacion() {
        System.out.println("Producto: " + nombre);
        System.out.println("Categoría: " + categoria);
        System.out.println("Precio: " + precio + " €");
        System.out.println("Stock: " + stock + " unidades");
    }

    // Método para aplicar un descuento al producto
    public void aplicarDescuento(double porcentaje) {
        if (porcentaje > 0 && porcentaje <= 100) {
            precio -= precio * (porcentaje / 100); // calcula el nuevo precio y lo actualiza
            System.out.println("Nuevo precio después del descuento: " + precio + " €");
        } else {
            System.out.println("Descuento no válido.");
        }
    }

    // Método para actualizar el stock del producto al aumentar su cantidad
    public void actualizarStock(int cantidad) {
        stock += cantidad;
        System.out.println("Stock actualizado. Nuevo stock: " + stock + " unidades.");
    }

    // Método para comprar el producto (reducir el stock)
    public void comprar(int cantidad) {
        if (cantidad <= stock) {
            stock -= cantidad; // se resta la cantidad de stock
            System.out.println("Compra realizada. Nuevo stock: " + stock + " unidades.");
        } else {
            System.out.println("No hay suficiente stock para esta compra.");
        }
    }

    
    public String getNombre() { // devuelve el nombre del producto
        return nombre;
    }

    public void setNombre(String nombre) { // establece el nombre del producto
        this.nombre = nombre;
    }

    public String getCategoria() { // devuelve la  categoría del producto
        return categoria;
    }

    public void setCategoria(String categoria) { // Establece la categoría del producto
        this.categoria = categoria;
    }

    public double getPrecio() { //  devuelve el precio del producto.
        return precio;
    }

    public void setPrecio(double precio) { // establece el precio
        this.precio = precio;
    }

    public int getStock() { // devuleve el stock
        return stock;
    }

    public void setStock(int stock) { // establece la cantidad de stock del producto
        this.stock = stock;
    }
}
