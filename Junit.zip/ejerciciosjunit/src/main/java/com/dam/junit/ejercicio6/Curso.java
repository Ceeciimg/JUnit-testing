package com.dam.junit.ejercicio6;

import java.util.ArrayList;

public class Curso {

    //atributos
    
    private String nombre;
    private ArrayList<Estudiante> estudiantes;
    private double notaMinimaAprobacion;

    // constructores 

    public Curso(String nombre, double notaMinimaAprobacion) { 
        this.nombre = nombre;
        this.notaMinimaAprobacion = notaMinimaAprobacion;
        this.estudiantes = new ArrayList<>(); // lista de estudiantes 
    }

    public boolean inscribirEstudiante(Estudiante estudiante) { // inscribe a un estudiante en el curso
        // Verificar que no se inscriba dos veces
        for (Estudiante e : estudiantes) {
            if (e.getNombre().equals(estudiante.getNombre())) { // si el estudiante ya esta inscrito devuelve false
                return false;
            }
        }
        estudiantes.add(estudiante);
        return true;
    }

    public double calcularPromedioGeneral() { // calcula el promedio general de todos los estudiaantes del cyrso
        if (estudiantes.isEmpty()) return 0.0;
        double suma = 0;
        for (Estudiante e : estudiantes) {
            suma += e.calcularPromedio();
        }
        return suma / estudiantes.size();
    }

    public ArrayList<Estudiante> obtenerEstudiantesAprobados() { // lista de estudiantes q estan aprobados
        ArrayList<Estudiante> aprobados = new ArrayList<>();
        for (Estudiante e : estudiantes) {
            if (e.estaAprobado(notaMinimaAprobacion)) {
                aprobados.add(e);
            }
        }
        return aprobados;
    }

    public ArrayList<Estudiante> getEstudiantes() { // devuleve la lista de estudiantes que estan inscritos en el curso
        return estudiantes;
    }
}
