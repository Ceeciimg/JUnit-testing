package com.dam.junit.ejercicio1;

    public class Calculadora {
    
        public int sumar(int a, int b) {  // suma
            return a + b;
        }
    
        public int restar(int a, int b) { // resta
            return a - b;
        }
    
        public int multiplicar(int a, int b) { //  multiplica
            return a * b;
        }
    
        public double dividir(int a, int b) {  // divide
            if (b == 0) {
                return Double.NaN;  // Si b == 0, devuelve Double.NaN (Not a Number).
            }
            return (double) a / b;
        }

       

    }

