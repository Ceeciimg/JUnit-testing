package com.dam.junit.ejercicio5;

public class ManipuladorCadenas {

    public String convertirMayusculas(String texto) { // convierte el texto en mayúsculas 
        return texto.toUpperCase();
    }

    public String invertirCadena(String texto) { //invierte la cadena de texto
        return new StringBuilder(texto).reverse().toString();
    }

    public int contarVocales(String texto) { //cuenta cuantas vocales hay en el texto
        int contador = 0;
        String vocales = "aeiouAEIOU";
        for (char c : texto.toCharArray()) {
            if (vocales.indexOf(c) != -1) {
                contador++;
            }
            // Depuración: ver los caracteres que estamos procesando
            System.out.println("Caracter: " + c + " | Contador: " + contador);
        }
        return contador;
    }

    public String concatenar(String texto1, String texto2) { // concatena las cadenas de texto 1 y texto 2
        return texto1 + texto2;
    }

    public boolean esPalindromo(String texto) { //compara la cadena con la invertida. Si son iguales, significa que es un palíndromo.
        String limpio = texto.replaceAll("\\s+", "").toLowerCase();
        return limpio.equals(new StringBuilder(limpio).reverse().toString());
    }
}
