package com.dam.junit.ejercicio7;

public class Libro {

    // atributos
    private String titulo;
    private boolean prestado;

    // constructor
    public Libro(String titulo) {
        this.titulo = titulo;
        this.prestado = false;
    }

    // devuleve el titutlo del libro

    public String getTitulo() {
        return titulo;
    }
     
    // indica si el libro esta prestado
    public boolean estaPrestado() {
        return prestado;
    }
     
    public void prestar() {
        this.prestado = true; // el libro esta prestado
    }

    public void devolver() {
        this.prestado = false; // el libro esta devuelto
    }
}
