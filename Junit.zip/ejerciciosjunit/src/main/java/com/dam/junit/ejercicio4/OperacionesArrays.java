package com.dam.junit.ejercicio4;

public class OperacionesArrays {

    public int suma(int[] numeros) { // calcula la suma de todos los elementos del array
        int resultado = 0;
        for (int num : numeros) {
            resultado += num;
        }
        return resultado;
    }

    public int producto(int[] numeros) { //Este método calcula el producto de todos los elementos del array numeros
        int resultado = 1;
        for (int num : numeros) {
            resultado *= num;
        }
        return resultado;
    }

    public double promedio(int[] numeros) { // calcula el promedio de los numeros del array
        if (numeros.length == 0) return 0;
        return (double) suma(numeros) / numeros.length;
    }

    public int maximo(int[] numeros) { // encuentra el valor máximo del aray
        int max = numeros[0];
        for (int num : numeros) {
            if (num > max) {
                max = num;
            }
        }
        return max;
    }

    public int minimo(int[] numeros) { //encuentra el valor mínimo del array
        int min = numeros[0];
        for (int num : numeros) {
            if (num < min) {
                min = num;
            }
        }
        return min;
    }
}
