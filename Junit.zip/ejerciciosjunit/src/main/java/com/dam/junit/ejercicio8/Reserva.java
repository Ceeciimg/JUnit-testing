package com.dam.junit.ejercicio8;

public class Reserva {

    // atributos
    private String nombreCliente;
    private int numeroHabitacion;
      // constructor
    public Reserva(String nombreCliente, int numeroHabitacion) {
        this.nombreCliente = nombreCliente;
        this.numeroHabitacion = numeroHabitacion;
    }

    public String getNombreCliente() { // devuelve el nombre del cliente q realizó la reserva
        return nombreCliente;
    }

    public int getNumeroHabitacion() { // devuelve el número de la habitación reservada
        return numeroHabitacion;
    }
}
