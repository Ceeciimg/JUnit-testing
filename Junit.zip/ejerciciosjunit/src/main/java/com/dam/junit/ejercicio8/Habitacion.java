package com.dam.junit.ejercicio8;

public class Habitacion {

    // atributos
    private int numero;
    private boolean reservada;

      // constructor 
    public Habitacion(int numero) {
        this.numero = numero;
        this.reservada = false;
    }
      // devuelve el numero de la habitación
    public int getNumero() {
        return numero;
    }
     // devuelve true si la habitación esta reservada
    public boolean estaReservada() {
        return reservada;
    }

    public void reservar() {
        this.reservada = true; //cambia el estado de reservada a true y marca la habitación como ocupada
    }

    public void cancelarReserva() {
        this.reservada = false; //  cambia el estado de reservada a false 
    }
}
