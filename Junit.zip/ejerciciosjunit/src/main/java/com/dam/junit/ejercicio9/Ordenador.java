package com.dam.junit.ejercicio9;

import java.util.ArrayList;
import java.util.List;

public class Ordenador {

    // atributos 
    private String marca;
    private String modelo;
    private String procesador;
    private int ramGB;
    private int almacenamientoGB;
    private static List<Ordenador> listaOrdenadores = new ArrayList<>();
      
    // constructor
    public Ordenador(String marca, String modelo, String procesador, int ramGB, int almacenamientoGB) {
        this.marca = marca;
        this.modelo = modelo;
        this.procesador = procesador;
        this.ramGB = ramGB;
        this.almacenamientoGB = almacenamientoGB;
        listaOrdenadores.add(this); // al crearse un ordenador, automaticamnete se añade a la lista
    }

    //Añade manualmente un objeto ordenador a la lista

    public static void agregarOrdenador(Ordenador ordenador) {
        listaOrdenadores.add(ordenador);
    }
        //devuelve la lista de todos los ordenadores almacenados
    public static List<Ordenador> obtenerListaOrdenadores() {
        return listaOrdenadores;
    }
        // muestra los detalles del ordenador
    public String obtenerDetalles() {
        return "Marca: " + marca + "\nModelo: " + modelo + "\nProcesador: " + procesador +
               "\nRAM: " + ramGB + "GB\nAlmacenamiento: " + almacenamientoGB + "GB";
    }
       // busca un ordenador en la lista por su modelo
    public static Ordenador buscarPorModelo(String modelo) {
        for (Ordenador o : listaOrdenadores) {
            if (o.modelo.equalsIgnoreCase(modelo)) {
                return o;
            }
        }
        return null;
    }

    // elimina todos los ordenadores de la lista

    public static void limpiarLista() {
        listaOrdenadores.clear();
    }
}
