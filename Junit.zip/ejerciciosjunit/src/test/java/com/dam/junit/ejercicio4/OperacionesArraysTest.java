
package com.dam.junit.ejercicio4;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

public class OperacionesArraysTest {

    private OperacionesArrays operaciones;
    private int[] valores;
    private int[] vacio;
    private int[] negativos;

    @BeforeAll // se ejecuta una vez antes de que comiencen todas las pruebas
    static void iniciarPruebas() {
        System.out.println("Iniciando pruebas de OperacionesArrays...");
    }

    @BeforeEach //  se ejecuta antes de cada prueba individual, para inicializar los objetos y los arrays
    void setUp() {
        operaciones = new OperacionesArrays();
        valores = new int[]{2, 4, 6, 8, 10};
        vacio = new int[]{};
        negativos = new int[]{-5, -2, -8, -1};
    }

    @Test
    @DisplayName("Sumar elementos de un array") 
    void testSuma() {
        assertEquals(30, operaciones.suma(valores), "La suma debe ser 30"); // compara la suma de los elementos del array  con 30.
        assertEquals(-16, operaciones.suma(negativos), "La suma debe ser -16");
        assertEquals(0, operaciones.suma(vacio), "La suma de un array vacío debe ser 0");
    }

    @Test
    @DisplayName("Multiplicar elementos de un array")
    void testProducto() {
        assertEquals(3840, operaciones.producto(valores), "El producto debe ser 3840"); //2 * 4 * 6 * 8 * 10 = 3840
        assertEquals(80, operaciones.producto(negativos), "El producto debe ser 80"); //-5 * -2 * -8 * -1 = 80
        assertEquals(1, operaciones.producto(vacio), "El producto de un array vacío debe ser 1 (neutro multiplicativo)");
    }

    @Test
    @DisplayName("Calcular el promedio de un array")
    void testPromedio() {
        assertEquals(6.0, operaciones.promedio(valores), "El promedio debe ser 6.0"); //30 / 5 = 6.0
        assertEquals(-4.0, operaciones.promedio(negativos), "El promedio debe ser -4.0"); //(-5 - 2 - 8 - 1) / 4 = -4.0.
        assertEquals(0.0, operaciones.promedio(vacio), "El promedio de un array vacío debe ser 0.0"); //El promedio de un array vacío es 0.0.
    }

    @Test
    @DisplayName("Obtener el máximo de un array")
    void testMaximo() {
        assertEquals(10, operaciones.maximo(valores), "El máximo debe ser 10"); //El valor máximo en {2, 4, 6, 8, 10} es 10.
        assertEquals(-1, operaciones.maximo(negativos), "El máximo debe ser -1"); // El valor máximo en {-5, -2, -8, -1} es -1
    }

    @Test
    @DisplayName("Obtener el mínimo de un array")
    void testMinimo() {
        assertEquals(2, operaciones.minimo(valores), "El mínimo debe ser 2"); //El valor mínimo en {2, 4, 6, 8, 10} es 2.
        assertEquals(-8, operaciones.minimo(negativos), "El mínimo debe ser -8"); //El valor mínimo en {-5, -2, -8, -1} es -8.
    }

    @AfterEach
    void tearDown() {
        System.out.println("Prueba finalizada.");
    }

    @AfterAll
    static void finalizarPruebas() {
        System.out.println("Todas las pruebas de OperacionesArrays han finalizado.");
    }
}
