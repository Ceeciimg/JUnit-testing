package com.dam.junit.ejercicio5;


import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

public class ManipuladorCadenasTest {

    private ManipuladorCadenas manipulador;

    @BeforeAll
    static void iniciarPruebas() {
        System.out.println("Iniciando pruebas de ManipuladorCadenas...");
    }

    @BeforeEach
    void setUp() {
        manipulador = new ManipuladorCadenas();
        System.out.println("Nueva prueba iniciada.");
    }

    @ParameterizedTest
    @CsvSource({  //se usa el @CsvSource para pasar varias cadenas de texto
        "'hola', 'HOLA'",
        "'Java', 'JAVA'",
        "'Pruebas', 'PRUEBAS'"
    })
    @DisplayName("Convertir una cadena a mayúsculas")
    void testConvertirMayusculas(String input, String resultadoEsperado) {
        assertEquals(resultadoEsperado, manipulador.convertirMayusculas(input), 
            "La conversión a mayúsculas de '" + input + "' debería ser '" + resultadoEsperado + "'.");
    }

    @Test
    @DisplayName("Invertir una cadena de texto")
    void testInvertirCadena() {

        assertEquals("aloh", manipulador.invertirCadena("hola"));
        assertEquals("avaJ", manipulador.invertirCadena("Java"));
        assertEquals("sabeurP", manipulador.invertirCadena("Pruebas"));
    
    }


    @Test
    @DisplayName("Contar vocales en una cadena de texto")
    void testContarVocales() {
        assertEquals(2, manipulador.contarVocales("hola"));  // o, a
        assertEquals(2, manipulador.contarVocales("Java"));  // a, a
        assertEquals(3, manipulador.contarVocales("pruebas")); // u, e, a
    
    }

    @Test
    @DisplayName("Concatenar dos cadenas")
    void testConcatenar() {

        assertEquals("HolaMundo", manipulador.concatenar("Hola", "Mundo"));
        assertEquals("JavaProgramacion", manipulador.concatenar("Java", "Programacion"));
        assertEquals("abc123", manipulador.concatenar("abc", "123"));
    }

    @Test
    @DisplayName("Verificar si una cadena es palíndromo")
    void testEsPalindromo() {
        assertTrue(manipulador.esPalindromo("Anita lava la tina"));  
        assertTrue(manipulador.esPalindromo("A man a plan a canal Panama")); 
        assertFalse(manipulador.esPalindromo("hola"));  
    }





    @AfterEach
    void tearDown() {
        System.out.println("Prueba finalizada.");
    }

    @AfterAll
    static void finalizarPruebas() {
        System.out.println("Todas las pruebas de ManipuladorCadenas han finalizado.");
    }
}