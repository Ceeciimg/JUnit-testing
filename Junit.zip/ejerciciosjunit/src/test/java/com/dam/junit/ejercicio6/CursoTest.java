package com.dam.junit.ejercicio6;

import java.util.ArrayList;
import java.util.Arrays;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

public class CursoTest {

    private Curso curso;
    private Estudiante estudiante1;
    private Estudiante estudiante2;
    private Estudiante estudiante3;

    @BeforeAll // se ejecuta una vez antes de q empiecen todas las pruebas
    static void iniciarPruebas() {
        System.out.println("Iniciando pruebas de Curso...");
    }

    //creación del curso y estudiantes
    @BeforeEach
    void setUp() {
        curso = new Curso("Programación", 5.0);

        estudiante1 = new Estudiante("cecilia", new ArrayList<>(Arrays.asList(6.0, 7.0, 8.0)));
        estudiante2 = new Estudiante("sofia", new ArrayList<>(Arrays.asList(4.0, 5.0, 4.0)));
        estudiante3 = new Estudiante("Carlos", new ArrayList<>(Arrays.asList(5.5, 6.5, 7.0)));
    }

    @Test
    @DisplayName("Inscripción de estudiantes")
    void testInscribirEstudiante() {
        assertTrue(curso.inscribirEstudiante(estudiante1));
        assertTrue(curso.inscribirEstudiante(estudiante2));
        assertTrue(curso.inscribirEstudiante(estudiante3));

        assertEquals(3, curso.getEstudiantes().size()); // verifica que se han creado tres estudiantes
    }

    @Test
    @DisplayName("No permitir inscribir al mismo estudiante dos veces")
    void testInscripcionDuplicada() {
        curso.inscribirEstudiante(estudiante1);
        
        assertFalse(curso.inscribirEstudiante(estudiante1), // no se puede inscribir un estudiante 2 veces
                    "El estudiante ya está inscrito en este curso.");
    }

    @Test
    @DisplayName("Calcular el promedio general del curso")
    void testCalcularPromedioGeneral() {
        curso.inscribirEstudiante(estudiante1);
        curso.inscribirEstudiante(estudiante2);
        curso.inscribirEstudiante(estudiante3);

        double promedioEsperado = (estudiante1.calcularPromedio() + estudiante2.calcularPromedio() + estudiante3.calcularPromedio());
        assertEquals(promedioEsperado, curso.calcularPromedioGeneral()); //Verifica que el promedio general calculado por el curso coincide con el valor esperado.
    }

    @Test
    @DisplayName("Obtener estudiantes aprobados")
    void testObtenerEstudiantesAprobados() {
        curso.inscribirEstudiante(estudiante1);
        curso.inscribirEstudiante(estudiante2);
        curso.inscribirEstudiante(estudiante3);

        ArrayList<Estudiante> aprobados = curso.obtenerEstudiantesAprobados(); //solo son 2 aprobados
        
        assertTrue(aprobados.contains(estudiante1)); // estudiante 1 esta en la lista de aprobados
        assertTrue(aprobados.contains(estudiante3)); // estudiante 3 esta en la lista de aprobados
        assertFalse(aprobados.contains(estudiante2)); // estudiante 2 no esta en la lista
    }

    @AfterEach
    void tearDown() {
        System.out.println("Prueba finalizada.");
    }

    @AfterAll
    static void finalizarPruebas() {
        System.out.println("Todas las pruebas de Curso han finalizado.");
    }
}