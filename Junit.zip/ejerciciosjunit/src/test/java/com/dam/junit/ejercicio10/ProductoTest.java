package com.dam.junit.ejercicio10;

import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

class ProductoTest {

    private Producto producto;

    @BeforeEach // se incia antes de cada prueba
    void setUp() {
        producto = new Producto("Camiseta", "Ropa", 20.0, 50);
    }

    @ParameterizedTest
    @CsvSource({ // se prueba el test con diferentes datos
        "10, 18.0",
        "25, 15.0",
        "50, 10.0"
    })
    void testAplicarDescuento(double porcentaje, double precioEsperado) {
        producto.aplicarDescuento(porcentaje);
        assertEquals(precioEsperado, producto.getPrecio(), 0.01); //verifica si el método aplicarDescuento actualiza correctamente el precio del producto al aplicar un porcentaje de descuento
    }

    @ParameterizedTest
    @CsvSource({
        "10, 60",
        "20, 70",
        "-5, 45"
    })
    void testActualizarStock(int cantidad, int stockEsperado) {
        producto.actualizarStock(cantidad);
        assertEquals(stockEsperado, producto.getStock()); //verifica si el método actualizarStock actualiza correctamente la cantidad de stock del producto.
    }

    @ParameterizedTest
    @CsvSource({
        "10, 40",
        "25, 25",
        "50, 0"
    })
    void testComprar(int cantidad, int stockEsperado) { //verifica si el método comprar reduce correctamente el stock del producto
        producto.comprar(cantidad);
        assertEquals(stockEsperado, producto.getStock());
    }

    @ParameterizedTest
    @CsvSource({
        "100, 50",
        "200, 50"
    })
    void testComprarSinStockSuficiente(int cantidad, int stockEsperado) { //no se puede comprar si no hay stock suficiente
        producto.comprar(cantidad);
        assertEquals(stockEsperado, producto.getStock()); // compara el stock actual con el stock esperado
    }

    @ParameterizedTest
    @CsvSource({
        "Zapato, Ropa, 50.0, 20",
        "Libro, Librería, 10.0, 100",
        "Smartphone, Electrónica, 300.0, 5"
    })
    void testConstructorConParametros(String nombre, String categoria, double precio, int stock) { //Verifica que el constructor asigna correctamente los valores del producto.
        Producto nuevoProducto = new Producto(nombre, categoria, precio, stock);
        assertEquals(nombre, nuevoProducto.getNombre()); //Verifica que el nombre del producto recién creado sea el que se pasó como parámetro.
        assertEquals(categoria, nuevoProducto.getCategoria());
        assertEquals(precio, nuevoProducto.getPrecio(), 0.01);
        assertEquals(stock, nuevoProducto.getStock());
    }
}
