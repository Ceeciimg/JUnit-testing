package com.dam.junit.ejercicio2;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.fail;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

@DisplayName("Pruebas de la Clase CuentaBancaria")
class CuentaBancariaTest {
    private CuentaBancaria cuenta;

    @BeforeAll  // se ejecuta una vez antes de todas las pruebas
    static void iniciarPruebas() {
        System.out.println("Iniciando pruebas de CuentaBancaria...");
    }

    @AfterAll
    static void finalizarPruebas() {
        System.out.println("Todas las pruebas han finalizado.");
    }

    @BeforeEach  //Antes de cada prueba, se crea una nueva cuenta con saldo de 100€, así todas las pruebas son independientes
    void setUp() {
        cuenta = new CuentaBancaria(100.0); // Cada prueba empieza con saldo de 100
        System.out.println("Nueva cuenta creada con saldo: " + cuenta.getSaldo());
    }

    @AfterEach //Se ejecuta al final, después de todas las pruebas.
    void tearDown() {
        System.out.println("Prueba finalizada, saldo final: " + cuenta.getSaldo()); //Muestra un mensaje con el saldo después de cada prueba.
    }

    @Test
    @DisplayName("Depositar dinero en la cuenta")
    void testDepositar() {
        cuenta.depositar(50); //deposita 50€
        assertEquals(150.0, cuenta.getSaldo(), "El saldo después del depósito debería ser 150."); //Verifica que el saldo ahora sea 150€ (100 + 50 = 150).
    }

    @Test
    @DisplayName("Retirar dinero con saldo suficiente")
    void testRetirarConSaldoSuficiente() {
        boolean resultado = cuenta.retirar(40); //retira 40e
        assertTrue(resultado, "El retiro debería ser exitoso.");
        assertEquals(60.0, cuenta.getSaldo(), "El saldo después del retiro debería ser 60."); //100-40 = 60
    }

    @Test
    @DisplayName("Intentar retirar más dinero del que hay")
    void testRetirarSinSaldoSuficiente() {
        boolean resultado = cuenta.retirar(200); // intenta retirar 200 pero el saldo es 100
        assertFalse(resultado, "El retiro no debería ser posible.");
        assertEquals(100.0, cuenta.getSaldo(), "El saldo no debería haber cambiado.");
    }

    @Test
    @DisplayName("Intentar retirar una cantidad negativa")
    void testRetirarCantidadNegativa() {
        boolean resultado = cuenta.retirar(-20); //intenta retirar -20e
        assertFalse(resultado, "No se puede retirar una cantidad negativa.");
        assertEquals(100.0, cuenta.getSaldo(), "El saldo no debería haber cambiado.");
    }

    @Test
    @Disabled("Funcionalidad en desarrollo")
    @DisplayName("Test en construcción: funcionalidad futura") // prueba desabilitada 
    void testFuncionalidadFutura() {
        fail("Este test está deshabilitado porque aún no se ha implementado.");
    }
}