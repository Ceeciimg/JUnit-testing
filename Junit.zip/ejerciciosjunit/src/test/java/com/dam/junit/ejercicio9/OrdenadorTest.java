package com.dam.junit.ejercicio9;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class OrdenadorTest {
    private Ordenador ordenador1;
    private Ordenador ordenador2;

    @BeforeEach // se ejecuta antes de cada prueba
    void setUp() {
        Ordenador.limpiarLista(); // Reiniciar la lista antes de cada prueba
        ordenador1 = new Ordenador("HP", "Pavilion", "Intel i5", 8, 512); // instancia 1
        ordenador2 = new Ordenador("Lenovo", "ThinkPad", "AMD Ryzen 7", 16, 1024); // instancia 2
    }

    @Test
    void testAgregarOrdenador() { // verificar que los ordenadores se agregan correctamnete a la lista
        assertEquals(2, Ordenador.obtenerListaOrdenadores().size()); // compara que el tamaño de la lista sea 2
    }

    @Test
    void testObtenerDetalles() {
        String detallesEsperados = "Marca: HP\nModelo: Pavilion\nProcesador: Intel i5\nRAM: 8GB\nAlmacenamiento: 512GB";
        assertEquals(detallesEsperados, ordenador1.obtenerDetalles()); //Llama al método obtenerDetalles()
    }

    @Test
    void testBuscarPorModelo() {
        assertEquals(ordenador2, Ordenador.buscarPorModelo("ThinkPad")); //Busca un ordenador en la lista de ordenadores con el modelo "ThinkPad" 
        assertNull(Ordenador.buscarPorModelo("MacBook")); //Busca un ordenador con el modelo "MacBook", per no está en la lista
    }
}
