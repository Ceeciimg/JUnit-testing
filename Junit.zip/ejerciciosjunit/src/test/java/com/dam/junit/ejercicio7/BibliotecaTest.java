package com.dam.junit.ejercicio7;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class BibliotecaTest {

    // atributos 

    private Biblioteca biblioteca;
    private Libro libro1;
    private Libro libro2;

    @BeforeEach
    void setUp() { // se inician los 3 atributos 
        biblioteca = new Biblioteca();
        libro1 = new Libro("El Quijote");
        libro2 = new Libro("Cien Años de Soledad");
    }

    @Test
    void testAgregarLibro() {
        // Agregar un libro nuevo
        assertTrue(biblioteca.agregarLibro(libro1), "El libro debería agregarse correctamente.");
        
        // no se puede agregar un libro duplicado
        assertFalse(biblioteca.agregarLibro(libro1), "No debería permitir agregar un libro duplicado.");
    }

    @Test
    void testPrestarLibro() {
        biblioteca.agregarLibro(libro1);
        
        // Prestar un libro disponible
        assertTrue(biblioteca.prestarLibro("El Quijote"), "El libro debería prestarse correctamente.");
        
        // Intentar prestar un libro que ya está prestado
        assertFalse(biblioteca.prestarLibro("El Quijote"), "No debería permitir prestar un libro que ya está prestado.");
        
        // Intentar prestar un libro que no está en la biblioteca
        assertFalse(biblioteca.prestarLibro("Don Juan Tenorio"), "No debería permitir prestar un libro que no existe.");
    }

    @Test
    void testDevolverLibro() {
        biblioteca.agregarLibro(libro1);
        biblioteca.prestarLibro("El Quijote");
        
        // Devolver un libro prestado
        assertTrue(biblioteca.devolverLibro("El Quijote"), "El libro debería devolverse correctamente.");
        
        // Intentar devolver un libro que no ha sido prestado
        assertFalse(biblioteca.devolverLibro("El Quijote"), "No debería permitir devolver un libro que no ha sido prestado.");
        
        // Intentar devolver un libro que no está en la biblioteca
        assertFalse(biblioteca.devolverLibro("Don Juan Tenorio"), "No debería permitir devolver un libro que no existe.");
    }
}
