package com.dam.junit.ejercicio8;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class HotelTest {

    private Hotel hotel;
    private Habitacion habitacion1;
    private Habitacion habitacion2;

    @BeforeEach
    void setUp() {
        hotel = new Hotel(5); // Crear un hotel con 5 habitaciones antes de cada prueba
    }

    @Test
    void testRealizarReserva() {
        // Realizar una reserva con exito 
        assertTrue(hotel.realizarReserva("Juan", 1), "La reserva debería ser exitosa.");
        
        // Intentar reservar una habitación ya ocupada
        assertFalse(hotel.realizarReserva("Maria", 1), "No debería permitir reservar una habitación ya ocupada.");
        
        // Intentar reservar una habitación que no existe
        assertFalse(hotel.realizarReserva("Pedro", 6), "No debería permitir reservar una habitación que no existe.");
    }

    @Test
    void testCancelarReserva() {
        hotel.realizarReserva("Juan", 1);
        
        // Cancelar una reserva ya existente
        assertTrue(hotel.cancelarReserva(1), "La reserva debería cancelarse correctamente.");
        
        // Intentar cancelar una reserva que no existe
        assertFalse(hotel.cancelarReserva(6), "No debería permitir cancelar una reserva que no existe.");
    }

    @Test
    void testObtenerReservasActivas() {
        hotel.realizarReserva("Juan", 1);
        hotel.realizarReserva("Maria", 2);
        
        // Comprobar que se devuelven las reservas activas correctas
        assertEquals(2, hotel.obtenerReservasActivas().size(), "Debe haber 2 reservas activas.");
        
        hotel.cancelarReserva(1);
        
        // Comprobar que solo queda 1 reserva activa después de cancelar una
        assertEquals(1, hotel.obtenerReservasActivas().size(), "Debe haber 1 reserva activa.");
    }
}
